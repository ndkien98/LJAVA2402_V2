package com.t3h.buoi20.di.dao;

public interface UserDao {

    void ketNoiDataBase();

    void truyVanDuLieu();
}
