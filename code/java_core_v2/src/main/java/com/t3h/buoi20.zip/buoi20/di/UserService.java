package com.t3h.buoi20.di;

import com.t3h.buoi20.di.dao.UserDao;

public class UserService {

    UserDao userDao;

    public UserService(UserDao userDao) {
        this.userDao = userDao;
    }

    public void layDanhSachUser(){
        userDao.ketNoiDataBase();
        userDao.truyVanDuLieu();
    }
}
