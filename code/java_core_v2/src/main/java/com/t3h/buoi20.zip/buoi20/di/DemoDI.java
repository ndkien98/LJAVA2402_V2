package com.t3h.buoi20.di;

import com.t3h.buoi20.di.dao.UserDao;
import com.t3h.buoi20.di.dao.UserDaoMysql;
import com.t3h.buoi20.di.dao.UserDaoOracle;

public class DemoDI {

    public static void main(String[] args) {

        UserService userService;
        UserDao userDao;
        // Khi muon ket noi su dung database Oracle
        userDao = new UserDaoOracle();
        userService = new UserService(userDao);
        userService.layDanhSachUser();

        userDao = new UserDaoMysql();
        userService = new UserService(userDao);
        userService.layDanhSachUser();

    }
}
